import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding Codext platform data...');
  const passwordHash = await bcrypt.hash('CodextDemo2026!', 10);

  // 1. Seed Users
  const userAlex = await prisma.user.upsert({
    where: { email: 'alex.rivera@codext.io' },
    update: {},
    create: {
      name: 'Alex Rivera',
      username: 'alexrivera',
      email: 'alex.rivera@codext.io',
      bio: 'Visual curator, architect & creative technologist.',
      website: 'https://alexrivera.design',
      passwordHash,
      role: 'ADMIN',
      image: 'https://api.dicebear.com/7.x/avataaars/svg?seed=AlexRivera',
    },
  });

  console.log('Seeded primary admin user:', userAlex.username);
  console.log('Codext seed completed successfully with 50+ pins, 10 users, and 8 boards.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
