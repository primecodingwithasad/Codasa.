# Codasa — Visual Discovery & Bookmarking Platform

Codasa is a production-ready, full-stack visual discovery and bookmarking platform engineered with a masonry feed, Pin creation, themed Boards with sections, social interactions, and comprehensive administrative moderation.

---

## 🚀 Features

- **Masonry Grid Feed**: Responsive, variable-height image tiles with blur-up placeholders and infinite scrolling.
- **Pin Management**:
  - Drag-and-drop image uploads with automatic aspect ratio calculation.
  - Save Pins from external URLs.
  - Interactive Pin details modal with high-res lightbox, comments with nested replies, like counts, and related recommendations.
- **Themed Boards & Sections**:
  - Public or secret boards.
  - Section categorization inside boards.
  - Pin reordering, moving, and deletion.
  - Collaborator invites.
- **Social Graph**:
  - Follow/unfollow creators.
  - Real-time notifications for likes, saves, comments, and new followers.
  - Rich user profiles with Created, Saved, and Board tabs.
- **Search & Discovery**:
  - Live search with instant suggestions and history.
  - Explore hub with curated collections and trending tags.
- **Admin Moderation**:
  - Pin reporting with an administrative dashboard to review and resolve flags.
- **Accessibility & Anti-Slop Design**:
  - Clean typographic hierarchy, zero pill clutter, WCAG AA compliance, and dark/light mode toggle.

---

## 🛠️ Tech Stack

- **Frontend**: Next.js 14 App Router, React 18, TypeScript, Tailwind CSS
- **Backend**: Next.js API Routes, Prisma ORM, PostgreSQL
- **Auth**: NextAuth.js (Email/Password credentials + Google OAuth)
- **Image Storage**: Cloudinary / S3 with WebP conversion
- **Validation**: Zod schema validation

---

## 🏁 Quickstart

### Prerequisites
- Node.js 18+ or 20+
- PostgreSQL database (or Docker)

### 1. Installation
```bash
npm install
```

### 2. Environment Setup
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Fill in your database connection string and NextAuth secret.

### 3. Database Migration & Seeding
```bash
npx prisma migrate dev --name init
npm run prisma:seed
```

### 4. Run Development Server
```bash
npm run dev
```
Visit `http://localhost:3000`.

---

## 🐳 Docker Setup

Run the full stack (Next.js app + PostgreSQL) with a single command:
```bash
docker-compose up --build
```

---

## 🗺️ Phase 2 Roadmap

1. **Direct Messaging**: End-to-end socket messaging to share pins and moodboards in real-time.
2. **Shopping & Merchant Pins**: Product pins with direct affiliate links, price tags, and stock trackers.
3. **AI Recommendations**: Vector embeddings (pgvector) for visual similarity search and personalized taste profile clustering.
4. **Native Mobile App**: React Native / Expo companion app for iOS and Android with system share-sheet integration.
